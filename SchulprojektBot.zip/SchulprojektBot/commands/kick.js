module.exports = {
    name:'kick',
    description:'kick member',
    execute(message, args){
        const member = message.mentions.users.first();
        if (member){
            const memberTarget = message.guild.members.cache.get(member.id);
            memberTarget.kick();
            const { MessageEmbed } = require('discord.js');
        const Discord = require('discord.js');
        const embed = new MessageEmbed()

        .setTitle("kicked")
        .setColor('#FFFFFF')
        .setDescription("Du hast <@"+ memberTarget + "> erfolgreich gekickt." )
        message.channel.send({embed});
        console.log('User wurde gekickt!')
        
            
        }else{
            const { MessageEmbed } = require('discord.js');
        const Discord = require('discord.js');
        const embed = new MessageEmbed()

        .setTitle("kick")
        .setColor('#FFFFFF')
        .setDescription("Du kannst diese Person nicht kicken")
        message.channel.send({embed});
        
        }
        

    }
}