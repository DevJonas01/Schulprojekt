module.exports = {
    name:'lesbian',
    description:'kate dkuray',
    
    execute(message, args, Discord){
        const redditFetch = require('reddit-fetch');

redditFetch({

    subreddit: 'lesbians',
    sort: 'hot',
    allowNSFW: true,
    allowModPost: true,
    allowCrossPost: true,
    allowVideo: true

}).then(post => {
    const Discord = require('discord.js');
    const { MessageEmbed } = require('discord.js');
    const embed = new MessageEmbed()

    .setTitle("lesbians")
    .setURL(`${post.url}`)
    .setColor('#ff5900')
    .setDescription("Only for the Boys!")
    .setFooter(`${message.author}`)
    if(!message.channel.nsfw){ message.reply("**Das hier ist kein NSFW Channel!**")
          return; }
    message.channel.send({embed})
    message.channel.send(`${post.url}`)
});
    }
}