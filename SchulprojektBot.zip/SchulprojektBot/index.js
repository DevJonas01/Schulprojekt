const Discord = require ('discord.js');
const client = new Discord.Client();
const api = require('imageapi.js')
const DisTube = require('distube');
const distube = new DisTube(client, { searchSongs: false, emitNewSongOnly: true })
const prefix = '*';
const {MessageButton, MessageActionRow} = require('discord-buttons')
require('discord-buttons')(client);

client.commands = new Discord.Collection();

const fs = require ('fs');
const { FILE } = require('dns');
const MemberCounter = require ('./counters/members')


const token = 'ODQ4MjE2MjQ1NzYwMTYzODYw.YLJY8A.U0_Wi-Q_aQr1LiriogZvjnnrpmk'

const commandFiles = fs.readdirSync('./commands/').filter(file => file.endsWith('.js'));
for(const file of commandFiles){
    const command = require(`./commands/${file}`);
 
    client.commands.set(command.name, command);
}

client.on('ready', (member) => {
    console.log(`You are logged in as ${client.user.tag}`);
    client.user.setActivity('Strg C at coding.', { type: 'WATCHING' });
    const logs = client.channels.cache.get('843774138388185108')
    logs.send(`Bot is online! Logged in as ${client.user.tag}` )
    MemberCounter(client);
});


  client.on('guildMemberAdd', async member => {
  const welcomechannel = client.channels.cache.get('843774138388185108')
  const welcomeEmbed = new Discord.MessageEmbed()

    welcomeEmbed.setColor('#5cf000')
    welcomeEmbed.setTitle('**' + member.user.username + '** ist jetzt im Offizellen **' + member.guild.memberCount + 'Server!')
    welcomeEmbed.setImage('https://www.google.com/url?sa=i&url=https%3A%2F%2Fbobsvagene.club%2Fpics%2Fcontroversial-nude-art-girls%2F&psig=AOvVaw3alHbHjtpMLTMP9_3FhQbf&ust=1632417058867000&source=images&cd=vfe&ved=0CAkQjRxqFwoTCMD_mcuJk_MCFQAAAAAdAAAAABAX')
    welcomechannel.send(welcomeEmbed)

})

client.on('message', message =>{
  if(!message.content.startsWith(prefix) || message.author.bot) return;

  const args = message.content.slice(prefix.length).split(/ +/);
  const command = args.shift().toLowerCase();

  const status = (queue) => `Volume: \`${queue.volume}%\` | Filter: \`${queue.filter || "Off"}\` | Loop: \`${queue.repeatMode ? queue.repeatMode == 2 ? "All Queue" : "This Song" : "Off"}\` | Autoplay: \`${queue.autoplay ? "On" : "Off"}\``;

// DisTube event listeners, more in the documentation page
distube
    .on("playSong", (message, queue, song) => message.channel.send(
        `Playing \`${song.name}\` - \`${song.formattedDuration}\`\nRequested by: ${song.user}\n${status(queue)}`
    ))
    .on("addSong", (message, queue, song) => message.channel.send(
        `Added ${song.name} - \`${song.formattedDuration}\` to the queue by ${song.user}`
    ))
    .on("playList", (message, queue, playlist, song) => message.channel.send(
        `Play \`${playlist.name}\` playlist (${playlist.songs.length} songs).\nRequested by: ${song.user}\nNow playing \`${song.name}\` - \`${song.formattedDuration}\`\n${status(queue)}`
    ))
    .on("addList", (message, queue, playlist) => message.channel.send(
        `Added \`${playlist.name}\` playlist (${playlist.songs.length} songs) to queue\n${status(queue)}`
    ))
    // DisTubeOptions.searchSongs = true
    .on("searchResult", (message, result) => {
        let i = 0;
        message.channel.send(`**Choose an option from below**\n${result.map(song => `**${++i}**. ${song.name} - \`${song.formattedDuration}\``).join("\n")}\n*Enter anything else or wait 60 seconds to cancel*`);
    })
    // DisTubeOptions.searchSongs = true
    .on("searchCancel", (message) => message.channel.send(`Searching canceled`))
    .on("error", (message, e) => {
        console.error(e)
        message.channel.send("An error encountered: " + e);
    });

  if(command === "play") {
    if(!message.member.voice.channel) return message.channel.reply('**Du bist in keinem Voicechannel!**');
    if(!args[0]) return message.channel.reply('Du musst einen Song angeben.');
    distube.play(message, args.join( " "));
  }

  if(command === "stop") {
    const bot = message.guild.members.cache.get(client.user.id);
    if(!message.member.voice.channel) return message.channel.reply('**Du bist in keinem Voicechannel!**');
    if(bot.voice.channel !== message.member.voice.channel) return message.channel.send("Du bist nicht im selben Channel wie der Bot");
    distube.stop(message);
    message.channel.send('Du hast die Musik gestoppt');
  }

    

  if(command === 'ping'){
      client.commands.get('ping').execute(message, args);
  } 
  if(command === 'clear'){
    client.commands.get('clear').execute(message, args);
  }
  if(command === 'pornhub'){
    client.commands.get('pornhub').execute(message, args);
  }
  if(command === 'kick'){
    client.commands.get('kick').execute(message, args);
  }
  if(command === 'ban'){
    client.commands.get('ban').execute(message, args);
  }
  if(command === 'kate'){
    client.commands.get('kate').execute(message, args);
  }
  if(command === 'ass'){
    client.commands.get('ass').execute(message, args);
  }
  if(command === 'cum'){
    client.commands.get('cum').execute(message, args);
  }
  if(command === 'teen'){
    client.commands.get('teen').execute(message, args);
  }
  if(command === 'porn'){
    client.commands.get('porn').execute(message, args);

  }if(command === 'lesbian'){
    client.commands.get('lesbian').execute(message, args);

  }if(command === 'help'){
    client.commands.get('help').execute(message, args);

  }if(command === 'rule34'){
    client.commands.get('rule34').execute(message, args);

  }if(command === 'hentai'){
    client.commands.get('hentai').execute(message, args);

  }if(command === 'pussy'){
  client.commands.get('pussy').execute(message, args);

  }if(command === 'cosplay'){
  client.commands.get('cosplay').execute(message, args);

  }if(command === 'reactionrole'){
    client.commands.get('reactionrole').execute(message, args, Discord, client);

  }if(command === 'rr'){
    client.commands.get('rr').execute(message, args, Discord, client);

  }if(command === 'irl'){
    client.commands.get('irl').execute(message, args, Discord, client);
  }




});

  




client.on('message', async msg => {
    if (msg.content ==='*meme') {
      let subreddits = [
        "memes",
      ];
      let subreddit = subreddits[Math.floor(Math.random()*(subreddits.length))];
      let img = await api(subreddit)
      const Embed = new Discord.MessageEmbed()
      .setTitle(`A meme from r/arabfunny`)
      .setURL(`https://www.reddit.com/r/arabfunny`)
      .setColor('RANDOM')
      .setImage(img)
      msg.channel.send(Embed)
    }
});


client.on('clickButton', async (button) => {
  if(button.id == 'AddXRole') {
    button.reply.send("Du hast die Rolle NSFW bekommen.", true)
    const role = button.guild.roles.cache.get("855941341746167829")
    const member = button.clicker.member
    await member.roles.add(role)

  }

    if(button.id == '1') {
      button.reply.send("Du hast die Rolle Valorant bekommen.", true)
      const role = button.guild.roles.cache.get("855931197418111036")
      const member = button.clicker.member
      await member.roles.add(role)
  

  } 
  
  if(button.id == '2') {
    button.reply.send("Du hast die Rolle CS:GO bekommen.", true)
    const role = button.guild.roles.cache.get("874989259243810847")
    const member = button.clicker.member
    await member.roles.add(role)


}
});

client.on('message', async (message) => {
  if (
    message.content.toLowerCase().startsWith(prefix + 'clear') ||
    message.content.toLowerCase().startsWith(prefix + 'c ')
  ) {
    if (!message.member.hasPermission('MANAGE_MESSAGES'))
      return message.channel.send("You cant use this command since you're missing `manage_messages` perm");
    if (!isNaN(message.content.split(' ')[1])) {
      let amount = 0;
      if (message.content.split(' ')[1] === '1' || message.content.split(' ')[1] === '0') {
        amount = 1;
      } else {
        amount = message.content.split(' ')[1];
        if (amount > 100) {
          amount = 100;
        }
      }
      await message.channel.bulkDelete(amount, true).then((_message) => {
        message.channel.send(`Bot cleared \`${_message.size}\` messages :broom:`).then((sent) => {
          setTimeout(function () {
            sent.delete();
          }, 2500);
        });
      });
    } else {
      message.channel.send('enter the amount of messages that you would like to clear').then((sent) => {
        setTimeout(function () {
          sent.delete();
        }, 2500);
      });
    }
  } else {
    if (message.content.toLowerCase() === prefix + 'help clear') {
      const newEmbed = new Discord.MessageEmbed().setColor('#00B2B2').setTitle('**Clear Help**');
      newEmbed
        .setDescription('This command clears messages for example `.clear 5` or `.c 5`.')
        .setFooter(`Requested by ${message.author.tag}`, message.author.displayAvatarURL())
        .setTimestamp();
      message.channel.send(newEmbed);
    }
  }
});


// Twitch Bot --- Went online and offline!




client.login(token)