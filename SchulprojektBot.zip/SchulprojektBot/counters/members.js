module.exports = async (client) =>{
    const guild = client.guilds.cache.get('843757960345550858');
    setInterval(() =>{
        const memberCount = guild.memberCount;
        const channel = guild.channels.cache.get('848624671330402334');
        channel.setName(`Idioten: ${memberCount.toLocaleString()}`);
        console.log('Updating Member Count');
    }, 5000);
  }
  