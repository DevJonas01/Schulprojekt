module.exports = {
    name:'ban',
    description:'ban a member',
    execute(message, args){
        const member = message.mentions.users.first();
        if (member){
            const memberTarget = message.guild.members.cache.get(member.id);
            memberTarget.ban();
            const { MessageEmbed } = require('discord.js');
        const Discord = require('discord.js');
        const author = message.author
        const embed = new MessageEmbed()

        .setTitle("Ban!")
        .setColor('#FFFFFF')
        .setDescription("<@"+message.author+">" +" hat " + "<@"+ memberTarget +">" + " erfolgreich gebannt." )
        message.channel.send({embed})
        console.log('User wurde gebannt.')
    
        
            
        }else{
            const { MessageEmbed } = require('discord.js');
        const Discord = require('discord.js');
        const embed = new MessageEmbed()

        .setTitle("Ban")
        .setColor('#FFFFFF')
        .setDescription("Du kannst diese Person nicht bannen.")
        message.channel.send({embed})
        }
        

    }
}

