module.exports = {
    name: 'help',
    discription:  'help cmd',

    execute(message, args){
        console.log('running help command');
        const Discord = require('discord.js');
        const { MessageEmbed } = require('discord.js');
        const embed = new MessageEmbed()

        .setColor('0000ff')
        .setTitle('Commands auf die ich höre !')
        .setDescription('Bei Nachfragen: Strg C#0001 | *help diese Seite')
        .addFields(
            { name: 'Mod-Commands', value: '*ban, *kick' },
            { name: 'NSFW Commands', value: '*cum, *ass, *porn, *lesbian, *kate, *teen, *rule34, *hentai' },
            { name: 'Inline field title', value: 'Some value here'},
        )
        .setTimestamp()
        .setFooter('Coded by Strg C #0001')
        .setTimestamp()

        message.channel.send({embed})


    


    }
}