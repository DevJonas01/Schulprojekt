module.exports= {
    name : 'irl',
    description : 'irl',
    

    execute(message, args, discord){
        const redditFetch = require('reddit-fetch');

redditFetch({

    subreddit: 'me_irl',
    sort: 'hot',
    allowNSFW: true,
    allowModPost: true,
    allowCrossPost: true,
    allowVideo: true,

}).then(post => {
    const Discord = require('discord.js');
    const { MessageEmbed } = require('discord.js');
    const embed = new MessageEmbed()

    .setTitle("/r/me_irl")
    .setURL(`${post.url}`)
    .setColor('#ff5900')
    .setDescription("Here a meme !")
    .setFooter(`${message.author}`)
    if(!message.channel.nsfw){ message.reply("**Das hier ist kein NSFW Channel!**")
          return; }
    message.channel.send({embed})
    message.channel.send(`${post.url}`)
});

    }
}