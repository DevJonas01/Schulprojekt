const ButtonPages = require('discord-button-pages');
const {MessageButton, MessageActionRow} = require('discord-buttons');
module.exports = {
    name:'rr',
    description:'rr',
    
     async execute(message, args, client, async, buttons){
       
        const Discord = require('discord.js');
        const { MessageEmbed } = require('discord.js');
        const embed = new Discord.MessageEmbed()
        .setTitle("Reaction Role")
        .setColor('Green')
        .setDescription('Klicke auf die Buttons um deine Rollen auszuwählen.')

        const add = new MessageButton()
        .setStyle("green")
        .setLabel("NSFW")
        .setID("AddXRole")

        const remove = new MessageButton()
        .setStyle("red")
        .setLabel("Valorant")
        .setID("1")

        const csgo = new MessageButton()
        .setStyle('grey')
        .setLabel('CS:GO')
        .setID('2')

        const row = new MessageActionRow()
        .addComponent([add, remove, csgo])


        message.channel.send({component: row, embed: embed})


        

    }


}