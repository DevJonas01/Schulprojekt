const { description, execute } = require("./Ping");
const Discord = require('discord.js');
module.exports = {
    name: 'clear',
    description: 'clear cmd',
    async execute(message, args, Discord) {
        if(!args[0]) return message.reply("``Bitte gebe an, wie viele Nachrichten du löschen willst!``");
        if(isNaN(args[0])) return message.reply("`Bitte gebe eine richtige Zahl an!``");
        

        if(args[0] > 100 ) return message.reply("``Bitte gebe eine Zahl zwischen 1 bis 100 an.``");
        if(args[0] < 1) return message.reply("``Die Zahl muss größer als 0 sein!``");

        await message.channel.messages.fetch({limit: args[0]}).then(messages =>{
            message.channel.bulkDelete(messages);
            const { MessageEmbed } = require('discord.js');
        const Discord = require('discord.js');
        const embed = new MessageEmbed()

        .setTitle("Gelöscht")
        .setColor('RANDOM')
        .setDescription(args[0]+ " Nachrichten wurden gelöscht!")
        message.channel.send({embed})
        });

    }


}