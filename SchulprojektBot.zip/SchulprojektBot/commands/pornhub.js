module.exports = {
    name:'pornhub',
    description:'cornhub',
    execute(message, args,){
        const { MessageEmbed } = require('discord.js');
        const Discord = require('discord.js');
        const embed = new MessageEmbed()

        .setTitle("Pornhub")
        .setURL("https://pornhub.com")
        .setColor('#ff5900')
        .setDescription("Only for the Boys!")
        .setFooter("Jonas ist schon nen guter Developer!")
        .setImage("https://upload.wikimedia.org/wikipedia/commons/f/f1/Pornhub-logo.svg")

        if(!message.channel.nsfw){ message.reply("**Das hier ist kein NSFW Channel!**")
          return; }
          
        message.channel.send({embed})



    }

}